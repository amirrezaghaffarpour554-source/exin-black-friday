<?php
/**
 * ProductSelectionService campaign module.
 *
 * @package ExinBlackFriday
 */

namespace Exin\BlackFriday\Application;

use Exin\BlackFriday\Domain\DiscountPlan;
use Exin\BlackFriday\Domain\Money;
use Exin\BlackFriday\Infrastructure\CampaignRepository;
use Exin\BlackFriday\Infrastructure\LockManager;
use Exin\BlackFriday\Infrastructure\Logger;
use Exin\BlackFriday\Integration\CampaignContext;

/** Validates campaign selections and preserves financial ownership. */
final class ProductSelectionService {
	/**
	 * Connect the services required by this module.
	 *
	 * @param CampaignRepository $repo Campaign persistence service.
	 */
	public function __construct( private CampaignRepository $repo ) {}

	/**
	 * Search published sellable products and variations with bounded pagination.
	 *
	 * @param string $term Product name or SKU search text.
	 * @param int    $page One-based result page.
	 * @param array  $filters Optional registered catalog filters.
	 *
	 * @return array Operation result.
	 */
	public function search( string $term, int $page = 1, array $filters = array() ): array {
		return ( new CatalogProductQuery() )->search( $term, $page, $filters );
	}

	/**
	 * Return bounded category, brand and global attribute filter choices.
	 *
	 * @return array Registered catalog filters for the administrator product picker.
	 */
	public function filters(): array {
		return ( new CatalogProductQuery() )->filters();
	}

	/**
	 * Calculate a private financial preview without saving changes.
	 *
	 * @param int    $campaign_id Campaign identifier.
	 * @param int    $product_id Sellable product or variation identifier.
	 * @param string $floor Requested floor price.
	 * @param array  $options Optional bulk floor policy resolved from the captured base.
	 *
	 * @return array Operation result.
	 * @throws \DomainException When unresolved ownership or invalid prices prevent preview.
	 */
	public function preview( int $campaign_id, int $product_id, string $floor, array $options = array() ): array {
		$campaign = $this->require_campaign( $campaign_id );
		if ( isset( $campaign['settings']['currency'] ) && ( get_woocommerce_currency() !== $campaign['settings']['currency'] || wc_get_price_decimals() !== (int) $campaign['settings']['precision'] ) ) {
			throw new \DomainException( 'store_currency_or_precision_changed' );
		}
		$product  = $this->require_product( $product_id );
		$existing = $this->repo->item( $campaign_id, $product_id );
		if ( $existing && 'removed' === $existing['status'] ) {
			if ( $existing['expected'] || $existing['intent'] ) {
				throw new \DomainException( 'restore_conflict_requires_resolution' );
			}
			$existing = null;
		}
		$snapshot = $existing ? $existing['snapshot'] : PriceState::capture( $product );
		if ( ! $existing ) {
			$this->eligible( $product, $snapshot, $campaign );
			if ( $this->repo->owned_elsewhere( $campaign_id, $product_id ) ) {
				throw new \DomainException( 'product_owned_by_another_campaign' );
			}
		}
		$base = $existing ? $existing['base_price'] : $this->base_price( $snapshot, $campaign );
		if ( isset( $options['floor_policy'] ) ) {
			$floor = $existing && ( 'none' === ( $options['floor_policy']['mode'] ?? 'none' ) || ( ! empty( $existing['floor_override'] ) && ! array_key_exists( $product_id, $options['floor_policy']['floors'] ?? array() ) ) )
				? $existing['floor_price']
				: BulkSelectionService::resolve_floor( $this->repo, $campaign, $product_id, $base, $options['floor_policy'], (int) ( $options['source_campaign_id'] ?? 0 ) );
		}
		$schedule = DiscountPlan::schedule( $base, $floor, $campaign );
		return array_merge(
			$this->presentation( $product ),
			array(
				'base_price'  => $base,
				'floor_price' => PriceState::money( $floor ),
				'schedule'    => $schedule,
			)
		);
	}

	/**
	 * Enroll a sellable product using one coherent immutable snapshot.
	 *
	 * @param int    $campaign_id Campaign identifier.
	 * @param int    $product_id Sellable product or variation identifier.
	 * @param string $floor Requested positive floor price.
	 * @param array  $options Optional presentation controls.
	 *
	 * @return array Operation result.
	 */
	public function add( int $campaign_id, int $product_id, string $floor, array $options = array() ): array {
		return ( new LockManager() )->run(
			'campaign:' . $campaign_id,
			function () use ( $campaign_id, $product_id, $floor, $options ) {
				return ( new LockManager() )->run(
					'product:' . $product_id,
					function () use ( $campaign_id, $product_id, $floor, $options ) {
						$campaign = $this->require_campaign( $campaign_id );
						if ( ! in_array( $campaign['status'], array( 'draft', 'scheduled', 'active', 'paused' ), true ) ) {
							throw new \DomainException( 'campaign_not_editable' );
						}
						if ( 'active' === $campaign['status'] && ( ! CampaignContext::is_live( $campaign ) || ! empty( $campaign['settings']['restoring'] ) ) ) {
							throw new \DomainException( 'campaign_not_editable' );
						}
						$winner = 'active' === $campaign['status'] ? $this->repo->winner_for_product( $product_id, time() ) : null;
						if ( $winner && (int) $winner['id'] !== $campaign_id ) {
							throw new \DomainException( 'product_owned_by_another_campaign' );
						}
						$previous = $this->repo->item( $campaign_id, $product_id );
						if ( $previous && ( 'removed' !== $previous['status'] || $previous['expected'] || $previous['intent'] ) ) {
							throw new \DomainException( 'product_already_included' );
						}
						if ( $this->repo->owned_elsewhere( $campaign_id, $product_id ) ) {
							throw new \DomainException( 'product_owned_by_another_campaign' );
						}
						$settings = $campaign['settings'];
						if ( isset( $settings['currency'] ) && ( get_woocommerce_currency() !== $settings['currency'] || wc_get_price_decimals() !== (int) $settings['precision'] ) ) {
							throw new \DomainException( 'store_currency_or_precision_changed' );
						}
						$settings['currency']  = get_woocommerce_currency();
						$settings['precision'] = wc_get_price_decimals();
						$this->repo->save( $campaign_id, array( 'settings' => $settings ) );
						$product  = $this->require_product( $product_id );
						$snapshot = PriceState::capture( $product );
						$this->eligible( $product, $snapshot, $campaign );
						if ( 'active' === $campaign['status'] ) {
							$owner_id = $product->get_stock_managed_by_id();
							$owner    = $owner_id === $product_id ? $product : wc_get_product( $owner_id );
							if ( 'instock' !== $product->get_stock_status() || ! $owner || ( $owner->managing_stock() && ( null === $owner->get_stock_quantity() || $owner->get_stock_quantity() <= 0 ) ) ) {
								throw new \DomainException( 'product_not_in_stock' );
							}
						}
						// Derive snapshot, base and schedule from the SAME captured object.
						$base = $this->base_price( $snapshot, $campaign );
						if ( isset( $options['floor_policy'] ) ) {
							$floor = BulkSelectionService::resolve_floor( $this->repo, $campaign, $product_id, $base, $options['floor_policy'], (int) ( $options['source_campaign_id'] ?? 0 ) );
						}
						if ( 'active' === $campaign['status'] && Money::parse( $floor, wc_get_price_decimals() ) <= 0 ) {
							throw new \DomainException( 'product_floor_required' );
						}
						$schedule                = DiscountPlan::schedule( $base, $floor, $campaign );
						$preview                 = array(
							'base_price'  => $base,
							'floor_price' => PriceState::money( $floor ),
							'schedule'    => $schedule,
						);
						$snapshot['precision']   = wc_get_price_decimals();
						$snapshot['currency']    = get_woocommerce_currency();
						$snapshot['captured_at'] = gmdate( 'Y-m-d H:i:s' );
						if ( $previous ) {
							$history                        = $previous['snapshot']['enrollment_history'] ?? array();
							$history[]                      = array_intersect_key( $previous['snapshot'], array_flip( array( 'regular', 'sale', 'price', 'from', 'to', 'precision', 'currency', 'captured_at' ) ) );
							$snapshot['enrollment_history'] = $history;
						}
						$this->repo->put_item(
							$campaign_id,
							$product_id,
							array(
								'base_price'     => $preview['base_price'],
								'floor_price'    => $preview['floor_price'],
								'schedule'       => $preview['schedule'],
								'snapshot'       => $snapshot,
								'expected'       => null,
								'intent'         => null,
								'retry_state'    => null,
								'operation_id'   => '',
								'conflict'       => '',
								'status'         => 'included',
								'priority'       => (int) ( $options['priority'] ?? 0 ),
								'featured'       => empty( $options['featured'] ) ? 0 : 1,
								'floor_override' => isset( $options['floor_override'] ) ? (int) (bool) $options['floor_override'] : ( isset( $options['floor_policy'] ) ? ( array_key_exists( $product_id, $options['floor_policy']['floors'] ?? array() ) ? 1 : 0 ) : 1 ),
							)
						);
						( new Logger() )->log(
							'info',
							$previous ? 'product_reenrolled' : 'product_included',
							array(
								'campaign_id' => $campaign_id,
								'product_id'  => $product_id,
								'result'      => 'success',
							)
						);
						return $this->repo->item( $campaign_id, $product_id );
					}
				);
			}
		);
	}


	/**
	 * Apply one explicitly added/resumed live item through the existing retry engine.
	 *
	 * @param int $campaign_id Active campaign identifier.
	 * @param int $product_id New or resumed member identifier.
	 * @return void
	 * @throws \DomainException When the live campaign or floor is invalid.
	 * @throws \RuntimeException When pricing is deferred to its durable retry.
	 */
	public function apply_current( int $campaign_id, int $product_id ): void {
		( new LockManager() )->run(
			'campaign:' . $campaign_id,
			function () use ( $campaign_id, $product_id ): void {
				$campaign = $this->require_campaign( $campaign_id );
				$item     = $this->repo->item( $campaign_id, $product_id );
				if ( 'active' !== $campaign['status'] || ! CampaignContext::is_live( $campaign ) || ! empty( $campaign['settings']['restoring'] ) || ! $item || Money::parse( $item['floor_price'], wc_get_price_decimals() ) < 0 ) {
					throw new \DomainException( 'product_floor_required' );
				}
				$settings = $campaign['settings'];
				$run      = $settings['last_run'] ?? array();
				if ( ( $run['version'] ?? null ) === $campaign['version'] && 'apply' === ( $run['mode'] ?? '' ) && ! isset( $run['pending_results'][ $product_id ] ) ) {
					$run['pending_results'][ $product_id ] = 'skipped';
					$run['skipped']                        = (int) ( $run['skipped'] ?? 0 ) + 1;
					$settings['last_run']                  = $run;
					$this->repo->save( $campaign_id, array( 'settings' => $settings ) );
				}
				// Persist the wake-up before attempting price writes; a request may die mid-batch.
				as_enqueue_async_action( 'exin_bf_retry', array( $campaign_id, $product_id, $campaign['version'], 'apply', 0 ), Scheduler::GROUP, true );
				( new Scheduler( $this->repo, new PriceProcessor( $this->repo, new Logger() ), new Logger() ) )->retry( $campaign_id, $product_id, $campaign['version'], 'apply', 0 );
				$item = $this->repo->item( $campaign_id, $product_id );
				if ( ! $item || ! $item['expected'] || $item['intent'] || 'active' !== $item['status'] ) {
					throw new \RuntimeException( 'live_price_retry_pending' ); }
			}
		);
	}

	/**
	 * Update allowed product controls and editable draft financial settings.
	 *
	 * @param int   $campaign_id Campaign identifier.
	 * @param int   $product_id Sellable product or variation identifier.
	 * @param array $data Allowlisted record fields.
	 *
	 * @return void Operation result.
	 */
	public function update( int $campaign_id, int $product_id, array $data ): void {
		( new LockManager() )->run(
			'campaign:' . $campaign_id,
			function () use ( $campaign_id, $product_id, $data ) {
				( new LockManager() )->run(
					'product:' . $product_id,
					function () use ( $campaign_id, $product_id, $data ) {
						$campaign = $this->require_campaign( $campaign_id );
						$item     = $this->repo->item( $campaign_id, $product_id );
						if ( ! $item || 'removed' === $item['status'] ) {
							throw new \DomainException( 'item_not_found' );
						}
						$changes = array_intersect_key( $data, array_flip( array( 'priority', 'featured', 'status', 'floor_override' ) ) );
						if ( isset( $changes['status'] ) ) {
							if ( ! in_array( $changes['status'], array( 'paused', 'included' ), true ) || in_array( $item['status'], array( 'conflict', 'completed' ), true ) ) {
								throw new \DomainException( 'invalid_item_transition' );
							}
							if ( 'paused' === $changes['status'] && ( $item['expected'] || $item['intent'] ) ) {
								( new PriceProcessor( $this->repo, new Logger() ) )->restore( $campaign_id, $product_id );
								$item = $this->repo->item( $campaign_id, $product_id );
								if ( $item['expected'] || $item['intent'] ) {
									throw new \DomainException( 'restore_conflict_requires_resolution' ); }
							}
							if ( 'included' === $changes['status'] && $item['expected'] ) {
								$changes['status'] = 'active';
							}
						}
						if ( isset( $data['floor_override'] ) && ( $item['expected'] || $item['intent'] ) ) {
							throw new \DomainException( 'financial_settings_frozen' ); }
						if ( isset( $data['floor_price'] ) || isset( $data['floor_policy'] ) ) {
							if ( 'draft' !== $campaign['status'] || $item['expected'] || $item['intent'] ) {
								throw new \DomainException( 'financial_settings_frozen' );
							}
							$preview                   = $this->preview( $campaign_id, $product_id, (string) ( $data['floor_price'] ?? $item['floor_price'] ), $data );
							$changes['floor_price']    = $preview['floor_price'];
							$changes['schedule']       = $preview['schedule'];
							$changes['floor_override'] = isset( $data['floor_override'] ) ? (int) (bool) $data['floor_override'] : ( isset( $data['floor_price'] ) || array_key_exists( $product_id, $data['floor_policy']['floors'] ?? array() ) ? 1 : (int) ( $item['floor_override'] ?? 0 ) );
						}
						if ( isset( $changes['priority'] ) ) {
							$changes['priority'] = (int) $changes['priority'];
						}
						if ( isset( $changes['featured'] ) ) {
							$changes['featured'] = (int) (bool) $changes['featured'];
						}
						$this->repo->put_item( $campaign_id, $product_id, $changes );
						( new Logger() )->log(
							'info',
							'item_updated',
							array(
								'campaign_id' => $campaign_id,
								'product_id'  => $product_id,
								'result'      => 'success',
							)
						);
					}
				);
			}
		);
	}

	/**
	 * Restore an owned price before marking the product removed.
	 *
	 * @param int $campaign_id Campaign identifier.
	 * @param int $product_id Sellable product or variation identifier.
	 *
	 * @return void Operation result.
	 */
	public function remove( int $campaign_id, int $product_id ): void {
		( new LockManager() )->run(
			'campaign:' . $campaign_id,
			function () use ( $campaign_id, $product_id ) {
				( new LockManager() )->run(
					'product:' . $product_id,
					function () use ( $campaign_id, $product_id ) {
						$item = $this->repo->item( $campaign_id, $product_id );
						if ( ! $item ) {
							throw new \DomainException( 'item_not_found' );
						}
						if ( $item['expected'] || $item['intent'] ) {
							( new PriceProcessor( $this->repo, new Logger() ) )->restore( $campaign_id, $product_id );
							$item = $this->repo->item( $campaign_id, $product_id );
							if ( $item['expected'] || $item['intent'] ) {
								throw new \DomainException( 'restore_conflict_requires_resolution' );
							}
						}
						$this->repo->put_item( $campaign_id, $product_id, array( 'status' => 'removed' ) );
						( new Logger() )->log(
							'info',
							'product_removed',
							array(
								'campaign_id' => $campaign_id,
								'product_id'  => $product_id,
								'result'      => 'success',
							)
						);
					}
				);
			}
		);
	}

	/**
	 * Apply an explicit safe decision to a product ownership conflict.
	 *
	 * @param int    $campaign_id Campaign identifier.
	 * @param int    $product_id Sellable product or variation identifier.
	 * @param string $decision Explicit safe conflict resolution decision.
	 *
	 * @return void Operation result.
	 * @throws \DomainException When the campaign, product, or requested operation fails validation.
	 */
	public function resolve( int $campaign_id, int $product_id, string $decision ): void {
		if ( 'retry' === $decision ) {
			( new LockManager() )->run(
				'campaign:' . $campaign_id,
				function () use ( $campaign_id, $product_id ) {
					( new LockManager() )->run(
						'product:' . $product_id,
						function () use ( $campaign_id, $product_id ) {
							$item = $this->repo->item( $campaign_id, $product_id );
							if ( ! $item ) {
								throw new \DomainException( 'item_not_found' );
							}
							if ( ! $item['expected'] && ! $item['intent'] ) {
								throw new \DomainException( 'no_owned_price_to_restore' );
							}
							// Explicit administrator retry resets the budget, never the financial fingerprint.
							$this->repo->put_item( $campaign_id, $product_id, array( 'retry_state' => null ) );
							( new PriceProcessor( $this->repo, new Logger() ) )->restore( $campaign_id, $product_id );
						}
					);
				}
			);
			return;
		}
		if ( 'keep_external' !== $decision ) {
			throw new \DomainException( 'invalid_resolution' );
		}
		( new LockManager() )->run(
			'campaign:' . $campaign_id,
			function () use ( $campaign_id, $product_id ) {
				( new LockManager() )->run(
					'product:' . $product_id,
					function () use ( $campaign_id, $product_id ) {
						$item = $this->repo->item( $campaign_id, $product_id );
						if ( ! $item || 'conflict' !== $item['status'] ) {
							throw new \DomainException( 'item_not_in_conflict' );
						}
						// Explicitly relinquish ownership; never overwrite the external price.
						$this->repo->put_item(
							$campaign_id,
							$product_id,
							array(
								'expected'    => null,
								'intent'      => null,
								'retry_state' => null,
								'status'      => 'removed',
								'conflict'    => 'external_price_retained',
							)
						);
						( new Logger() )->log(
							'warning',
							'ownership_relinquished',
							array(
								'campaign_id' => $campaign_id,
								'product_id'  => $product_id,
								'result'      => 'external_price_retained',
							)
						);
					}
				);
			}
		);
	}

	/**
	 * Load a campaign or fail with a stable internal error code.
	 *
	 * @param int $id Record identifier.
	 *
	 * @return array Operation result.
	 * @throws \DomainException When the campaign, product, or requested operation fails validation.
	 */
	private function require_campaign( int $id ): array {
		$campaign = $this->repo->get( $id );
		if ( ! $campaign ) {
			throw new \DomainException( 'campaign_not_found' );
		}
		return $campaign;
	}

	/**
	 * Load a supported published sellable WooCommerce product.
	 *
	 * @param int $id Record identifier.
	 *
	 * @return \WC_Product Operation result.
	 * @throws \DomainException When the campaign, product, or requested operation fails validation.
	 */
	private function require_product( int $id ): \WC_Product {
		$product = wc_get_product( $id );
		if ( ! $product || ! in_array( $product->get_type(), array( 'simple', 'variation' ), true ) ) {
			throw new \DomainException( 'unsupported_or_missing_product' );
		}
		$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		if ( ! $parent || 'publish' !== $parent->get_status() || 'publish' !== $product->get_status() ) {
			throw new \DomainException( 'product_not_published' );
		}
		return $product;
	}

	/**
	 * Reject existing sales and incompatible dynamic pricing.
	 *
	 * @param \WC_Product $product WooCommerce product object.
	 * @param array       $snapshot Immutable original financial fingerprint.
	 * @param array       $campaign Campaign with an explicit existing-sale policy.
	 *
	 * @return void Operation result.
	 * @throws \DomainException When the campaign, product, or requested operation fails validation.
	 */
	private function eligible( \WC_Product $product, array $snapshot, array $campaign ): void {
		$preserve_sale = ! empty( $campaign['settings']['discount_plan'] ) && 'preserve' === ( $campaign['settings']['existing_sale_policy'] ?? '' );
		if ( ! $preserve_sale && ( '' !== $snapshot['sale'] || $snapshot['from'] || $snapshot['to'] ) ) {
			throw new \DomainException( 'existing_or_scheduled_sale_conflict' );
		}
		$precision = wc_get_price_decimals();
		if ( '' === $snapshot['regular'] || '' === $snapshot['price'] || Money::parse( $snapshot['regular'], $precision ) <= 0
			|| Money::parse( $snapshot['price'], $precision ) < 0
			|| Money::parse( $snapshot['regular'], $precision ) < Money::parse( $snapshot['price'], $precision )
			|| ( ! $preserve_sale && $snapshot['regular'] !== $snapshot['price'] )
			|| ( $preserve_sale && $snapshot['regular'] !== $snapshot['price'] && ( '' === $snapshot['sale'] || $snapshot['sale'] !== $snapshot['price'] ) )
			|| ( $preserve_sale && '' !== $snapshot['sale'] && ( Money::parse( $snapshot['sale'], $precision ) < 0 || Money::parse( $snapshot['sale'], $precision ) > Money::parse( $snapshot['regular'], $precision ) ) ) ) {
			throw new \DomainException( 'regular_price_conflict' );
		}
		if ( PriceState::dynamic( $product ) ) {
			throw new \DomainException( 'dynamic_price_conflict' );
		}
	}

	/**
	 * Use the original regular price for a general campaign without stacking sales.
	 *
	 * @param array $snapshot Full original WooCommerce financial fingerprint.
	 * @param array $campaign Campaign and explicit sale-preservation policy.
	 * @return string Canonical, validated immutable campaign base.
	 */
	private function base_price( array $snapshot, array $campaign ): string {
		return ! empty( $campaign['settings']['discount_plan'] ) && 'preserve' === ( $campaign['settings']['existing_sale_policy'] ?? '' ) ? $snapshot['regular'] : $snapshot['price'];
	}

	/**
	 * Build the private administrator product selection summary.
	 *
	 * @param \WC_Product $product WooCommerce product object.
	 *
	 * @return array Operation result.
	 */
	private function presentation( \WC_Product $product ): array {
		return CatalogProductQuery::presentation( $product );
	}
}
