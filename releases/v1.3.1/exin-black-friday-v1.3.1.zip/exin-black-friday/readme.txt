=== EXIN Black Friday ===
Contributors: exin
Tags: woocommerce, campaign, black-friday, pricing
Requires at least: 6.5
Requires PHP: 8.2
Stable tag: 1.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: exin-black-friday

مدیریت کمپین بلک فرایدی اکسین با تقویم شمسی، انتخاب چندمحصولی، تخفیف زمان‌دار و بازیابی امن.

== Description ==

مدیریت چند کمپین مستقل با سه مرحلهٔ انتخاب محدوده، تخفیف و زمان‌بندی، پیش‌نمایش و فعال‌سازی. تخفیف اولیه، درصد/مبلغ ثابت، خطی، پلکانی و سفارشی در بازه‌های روزانه، ساعتی یا دقیقه‌ای پشتیبانی می‌شوند. انتخاب تمام نتایج و تعیین گروهی کف قیمت در دسته‌های سرور و بدون محدودیت ۲۰۰ محصول انجام می‌شود. محاسبات مالی با واحد صحیح پول انجام می‌شوند. شروع کمپین تأیید مدیر می‌خواهد و پیش‌نویس قیمت محصول را تغییر نمی‌دهد.

فقط محصولات منتخب موجود و قابل خرید نمایش داده می‌شوند. شورت‌کد و ویجت‌های Elementor منبع محصول طراحی موجود را تأمین می‌کنند؛ هسته به Elementor یا Woodmart وابستگی اجباری ندارد.

ارسال یارانه‌ای فقط Flat Rate مجاز را تغییر می‌دهد: حداقل صفر یعنی بدون حداقل برای اقلام واجد شرایط؛ سقف سهم هزینهٔ پایهٔ فروشگاه به‌طور پیش‌فرض ۱۵۰٬۰۰۰ تومان برای کل سبد است. مابه‌التفاوت از مشتری دریافت می‌شود. این سقف، سقف خرید مشتری نیست.

کف قیمت فقط حداقل قیمت خود موتور است؛ کوپن یا تخفیف خارجی ممکن است مبلغ نهایی را پایین‌تر ببرد. هدف سفارش حذف شده و تعداد سفارش‌های کمپین محدود نیست. گزارش‌ها از سفارش واقعی و Metadata با پشتیبانی HPOS و Refund ساخته می‌شوند.

نسخه ابتدا روی Staging مشابه فروشگاه، همراه بکاپ قابل بازیابی، بررسی شود. ماتریس واقعی اجرا و موارد Not Run در docs/testing.md ثبت می‌شوند.

== Installation ==

1. از دیتابیس و فایل‌های فروشگاه بکاپ قابل بازیابی بگیرید و Staging مستقل بسازید.
2. WooCommerce را فعال و exin-black-friday-v1.0.1.zip را از بخش افزونه‌ها نصب یا جایگزین کنید.
3. در پیش‌نویس، نام، تاریخ شمسی، ساعت و مدت کمپین را تعیین کنید.
4. محصولات و کف‌ها را با Picker انتخاب و پیش‌نمایش را بررسی کنید.
5. پس از تست ارسال، خرید، صف و Restore، فعال‌سازی کمپین را صریحاً تأیید کنید.

== Frequently Asked Questions ==

= آیا ذخیرهٔ خودکار کمپین را شروع می‌کند؟ =

خیر. پیش‌نویس از فعال‌سازی جداست و قیمت‌ها را تغییر نمی‌دهد.

= سقف ۱۵۰٬۰۰۰ تومان یعنی حداکثر مبلغ سفارش؟ =

خیر. این سقف سهم فروشگاه از هزینهٔ پایهٔ ارسال است. برای هزینهٔ بیشتر، مشتری مابه‌التفاوت و مالیات متناظر را می‌پردازد. بسته‌های مشمول از یک بودجهٔ مشترک استفاده می‌کنند.

= مبلغ‌ها ریال‌اند یا تومان؟ =

ذخیره و محاسبه در واحد استاندارد ووکامرس است. برای IRR نمایش تومان با تبدیل دقیق ۱۰ به ۱ انجام می‌شود؛ IRT/TMN تومان هستند. تبدیل ارز خارجی انجام نمی‌شود.

= محصول ناموجود نمایش داده می‌شود؟ =

خیر. ناموجود، غیرقابل خرید و موجودی مدیریت‌شدهٔ صفر از فهرست جشنواره حذف می‌شوند؛ موجودی خود محصول تغییر نمی‌کند.

= توقف، قیمت را برمی‌گرداند؟ =

خیر. توقف فقط تغییرات آینده را متوقف می‌کند. Restore جداگانه با تأیید مدیر یا در پایان طبیعی انجام می‌شود.

= حذف داده و Rollback چگونه است؟ =

داده هنگام حذف به‌طور پیش‌فرض حفظ می‌شود. Opt-in پاک‌سازی در حضور مالکیت یا Intent باز رد می‌شود. بازگشت فایل افزونه به‌تنهایی قیمت‌ها را برنمی‌گرداند؛ راهنمای docs/rollback-fa.md را اجرا کنید.

== Changelog ==

= 1.3.1 =
Inline draft floors with bounded bulk save and cross-page edits; stock-only manager pages, SKU/ID search and variation color/stock. Existing financial locks remain.

= 1.3.0 =
Explicit automatic progressive, descending, rotation, seeded random, wave and hybrid profiles. Regular-to-floor arithmetic, immutable turn cohorts, Flash capacity guard, last-day policies and paged previews reuse the existing price/restore/scheduler paths. Independent automatic duration derives stage counts (7 days / 5 minutes = 2016). Lazy next-boundary scheduling and bounded previews avoid prebuilt stage/product jobs. Schema 6 widens the turn stage column and leaves existing manual campaigns untouched.


= 1.2.2 =
Allow bounded enrollment of new WooCommerce products into a live campaign with required positive floors and per-product exceptions. Preserve existing products and schedule; apply the current stage. Safely restore individual paused/removed products and resume interrupted enrollment.


= 1.2.1 =
Recheck campaign lifecycle/deadline before new-product enrollment. Correct catalog counts, empty-price and parent visibility filtering, visibility taxonomy IDs and out-of-range pagination.


= 1.2.0 =
Operational settings, coupon floor policy, cart stage refresh, bounded public catalogs, new product policies, notifications and HPOS audit/report additions. Additive schema 4 upgrade preserves financial state. See docs/upgrade-v1.2.0.md.


= 1.1.0 =
* چند کمپین، کپی و آرشیو امن؛ تخفیف اولیه و زمان‌بندی منعطف؛ انتخاب سروری بدون محدودیت ۲۰۰؛ کف گروهی، پیش‌نمایش و گزارش تغییر واقعی قیمت.

= 1.0.1 =
* تقویم شمسی، Product Picker چندگانه، فرمت اعداد، ارسال با سقف سهم فروشگاه، ترتیب پویای موجودها و تنظیم گزارش در عیب‌یابی.
* حفظ ایمنی قیمت و دادهٔ کمپین در ارتقا از 1.0.0؛ هدف سفارش حذف شد.

= 1.0.0 =
* انتشار اولیه برای ارزیابی Staging؛ موتور مالی، زمان‌بندی، بازیابی، مدیریت، نمایش و گزارش.
